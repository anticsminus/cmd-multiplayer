/**********************(
	*Welcome to CMD battleships
	*Game networking lab one
	*Name: Christopher Landry
	*This game is a local battleships variant, allows players to input coords and place ships on the board
	*Ships are not revealed until the player attacks the area
	
	Student ID: 4259228

*/

#include <iostream>
#include "Game.h"

string name;
Player* p1;
Player* p2;


using namespace std;

void initNames() //function for initializing the names
{
	cout << "Welcome to Battleships! A local multiplayer game between two players" << endl;
	cout << "\n\nPlease enter your name for player one: ";
	cin >> name; //take input from console for name 
	p1 = new Player(name); //set to specific player 

	//rinse & repeat for player 2
	cout << "\nPlease enter your name for player two: ";
	cin >> name;
	p2 = new Player(name);
	p2->iAmountOfTurns = 1; //set the turn for player two higher so that player one will start first 
	system("cls");
	Game game(p1, p2); //attach players
	//complete board setup
	p1->bcompletedSetup = game.setupBoard(p1);
	if (p1->bcompletedSetup == true)
	{
		p2->bcompletedSetup = game.setupBoard(p2);
	}
	game.displayBoard(p1);
}

int main()
{
	initNames();
	

	system("PAUSE");
	return 0;
}