#include "Game.h"  


void displayBoard(Player* WhatPlayer);


Piece * p1pieces = new Piece[4];
Piece * p2pieces = new Piece[4];

void Game::startGame()
{
	//reset player two
	LocalPlayerOne->bHasAttacked = false;
	LocalPlayerOne->bIsActivePiece = false;
	LocalPlayerOne->bcompletedSetup = false;
	LocalPlayerTwo->iGamesPlayed++;
	//reset player one
	LocalPlayerTwo->bHasAttacked = false;
	LocalPlayerTwo->bIsActivePiece = false;
	LocalPlayerTwo->bcompletedSetup = false;
	LocalPlayerTwo->iGamesPlayed++;
	LocalPlayerTwo->iAmountOfTurns = 1;
	setupBoard(LocalPlayerOne);
	setupBoard(LocalPlayerTwo);
	displayBoard(LocalPlayerOne);
}

int Game::enterRowPosition()
{
	int row = 0;
	do
	{
		cout << "Enter row (from 1-5): ";
		cin >> row;
		if (row < 1 || row > 6)
		{
			enterRowPosition();
		}
	} while (row < 1 || row >= 6);

	return row - 1;
}

//function for getting col coord from player
int Game::enterColPosition()
{
	char col;
	int column = 0;
	cout << "Enter column (A,B,C,D,E): ";
	cin >> col;

	switch (col)
	{
	default: 
		enterColPosition();
		break;
	case 'A':
		column = 0;
		break;
	case 'B':
		column = 1;
		break;
	case 'C':
		column = 2;
		break;
	case 'D':
		column = 3;
		break;
	case 'E':
		column = 4;
		break;
	}
	if (col != 'A' && col != 'B' && col != 'C' && col != 'D' && col != 'E')
	{
		enterColPosition();
	}
	return column;
}

//after each turn we check to see if win conditions have been met, if they have then let the player decide 

void Game::checkForWinner()
{
	int iInput;
	if (LocalPlayerOne->iPiece == 0)
	{
		cout << endl;
		LocalPlayerTwo->iWins++;
		cout << LocalPlayerTwo->getNames() << " has won! \n\nType [0] to end game or [1] to restart ";
		cin >> iInput;
		if (iInput == 0)
		{
			delete LocalPlayerOne;
			delete LocalPlayerTwo;
			delete p1pieces;
			delete p2pieces;

			system("exit");
		}
		if (iInput == 1)
		{
			startGame();
		}
	}
	else if (LocalPlayerTwo->iPiece == 0)
	{
		cout << endl;
		LocalPlayerOne->iWins++;
		cout << LocalPlayerOne->getNames() << " has won! \n\nType: \n[0] End game \n[1] Restart ";
		cin >> iInput;
		if (iInput == 0)
		{
			delete LocalPlayerOne;
			delete LocalPlayerTwo;
			delete p1pieces;
			delete p2pieces;
			
			system("exit");
		}
		if (iInput == 1)
		{
			startGame();
		}
		else
		{
			cout << "Not a valid command!" << endl;
		}
	}



}


//check if grid corresponds with piece
bool Game::GetGrid(int col, int row, Player* WhatPlayer)
{
	if (WhatPlayer == LocalPlayerOne)
	{
		for (int x = 0; x < 4; x++)
		{
			for (int y = 0; y < 4; y++)
			{

				if (col == p2pieces[x].x)
				{
					if (row == p2pieces[y].y)
					{
						return true;
					}
				}
				else
				{
					return false;
				}
			}
		}
	}
	if (WhatPlayer == LocalPlayerTwo)
	{
		for (int x = 0; x < 4; x++)
		{
			for (int y = 0; y < 4; y++)
			{

				if (col == p1pieces[x].x)
				{
					if (row == p1pieces[y].y)
					{
						return true;
					}
				}
				else
				{
					return false;
				}
			}
		}
	}
}

bool Game::setupBoard(Player* &WhatPlayer)
{

	if (WhatPlayer == LocalPlayerOne)
	{
		if (WhatPlayer->iAmountOfTurns == 0)
		{
			for (LocalPlayerOne->iPlacedPieces; LocalPlayerOne->iPlacedPieces < 4; LocalPlayerOne->iPlacedPieces++)
			{

				cout << LocalPlayerOne->getNames() << "\n" << endl;
				cout << "Welcome to the introduction!\nFirst we have to identify where the ships are in the water.\n\nSymbols:\n-X's represent hit's on the enemies board\n-O's represent misses\n-~ represents unknown waters\n\nPlease start by placing the remaining amount of ships on the board: " << LocalPlayerOne->iPiece - LocalPlayerOne->iPlacedPieces << endl;

				p1pieces[LocalPlayerOne->iPlacedPieces].x = enterColPosition();
				p1pieces[LocalPlayerOne->iPlacedPieces].y = enterRowPosition();
				
				system("cls");
			}
			LocalPlayerOne->iAmountOfTurns++;


		}
	}
	if (WhatPlayer == LocalPlayerTwo)
	{
		if (WhatPlayer->iAmountOfTurns == 1)
		{

			for (LocalPlayerTwo->iPlacedPieces; LocalPlayerTwo->iPlacedPieces < 4; LocalPlayerTwo->iPlacedPieces++)
			{

				cout << LocalPlayerTwo->getNames() << "\n\n" << endl;
				cout << "Welcome to the introduction!\nFirst we have to identify where the ships are in the water.\n\nSymbols:\n-X's represent hit's on the enemies board\n-O's represent misses\n-~ represents unknown waters\n\nPlease start by placing the remaining amount of ships on the board: " << LocalPlayerTwo->iPiece - LocalPlayerTwo->iPlacedPieces << endl;
				p2pieces[LocalPlayerTwo->iPlacedPieces].x = enterColPosition();
				p2pieces[LocalPlayerTwo->iPlacedPieces].y = enterRowPosition();
				system("cls");

			}
			LocalPlayerTwo->iAmountOfTurns++;


		}
	}
	return true;
}

int Game::processTurn(Player* &WhatPlayer)
{
	bool isOccupied = false;
	int col;
	int row;
	if (WhatPlayer->bcompletedSetup == false)
	{
		WhatPlayer->bcompletedSetup = setupBoard(LocalPlayerOne);
	}
	else
	{
		cout << WhatPlayer->getNames() << " it is your turn! Time to make a move\nType [1] Attack\nType [2] End Turn " << endl;
		cin >> WhatPlayer->playerinput;
		switch (WhatPlayer->playerinput)
		{
		default:
			cout << "That is not a valid option" << endl;
			processTurn(WhatPlayer);
			break;
		case ATTACK:
			if (WhatPlayer->bHasAttacked == false)
			{
				col = enterColPosition();
				row = enterRowPosition();
				WhatPlayer->bHasAttacked = true;
				//			board[col][row][i] = HitCheck::HIT;
							// checkl to see if piece is at that location
							// if so // mark that peice as hit once
							// update the board at that location to show hitcheck::HIT
							// else it's a miss but still update board
				if (WhatPlayer == LocalPlayerOne)
				{
					//check if input is occupied with the piece grid
					isOccupied = GetGrid(col, row, LocalPlayerOne);
					if (isOccupied == true)
					{
						board2[col][row] = HitCheck::HIT; //print hit

					}
					else
					{
						board2[col][row] = HitCheck::MISS; //print midd
					}
				}
				if (WhatPlayer == LocalPlayerTwo)
				{
					isOccupied = GetGrid(col, row, LocalPlayerTwo);
					if (isOccupied == true)
					{
						board[col][row] = HitCheck::HIT;

					}
					else
					{
						board[col][row] = HitCheck::MISS;
					}
				}
				LocalPlayerOne->iAmountOfTurns < LocalPlayerTwo->iAmountOfTurns ? displayBoard(LocalPlayerOne) : displayBoard(LocalPlayerTwo);
			}
			else
			{
				cout << "You have already attacked, please choose one of the following options\n" << endl;
				cout << "[2]End Turn" << endl;
				cin >> WhatPlayer->playerinput;
			}
			break;

		case ENDTURN:

			system("cls");

			WhatPlayer->iAmountOfTurns += 1;
			WhatPlayer->bHasAttacked = false;
			WhatPlayer->playerinput = NUL;
			LocalPlayerOne->iAmountOfTurns < LocalPlayerTwo->iAmountOfTurns ? displayBoard(LocalPlayerOne) : displayBoard(LocalPlayerTwo);
			break;
		}
	}
	return 0;
}



void Game::displayBoard(Player* &WhatPlayer)
{
	system("cls");
	cout << "It is " << WhatPlayer->getNames() << "'s turn \n" << endl;
	cout << "    A    B    C    D    E\n\n";

	for (int row = 0; row < 5; row++)
	{
		cout << row + 1;
		for (int col = 0; col < 5; col++)
		{
			//we have two boards to keep track of shots / misses for each player - used to compare with piece coords
			cout << " ";
			if (WhatPlayer == LocalPlayerOne)
			{
				cout << "  " << board2[col][row] << " ";
			}
			if (WhatPlayer == LocalPlayerTwo)
			{
				cout << "  " << board[col][row] << " ";
			}

		}
		cout << endl;
	}
	cout << "\n\n" << LocalPlayerOne->getNames() << "\t\t	" << LocalPlayerTwo->getNames() << endl;
	cout << "Ships remaining: " << LocalPlayerOne->iPiece << "\tShips remaining: " << LocalPlayerTwo->iPiece << endl;
	cout << "Turns elapsed: " << LocalPlayerOne->iAmountOfTurns - 1 << "\tSTurns Elapsed: " << LocalPlayerTwo->iAmountOfTurns + 1 << endl;
	cout << "-------------------------------------------------" << endl;
	checkForWinner();
	LocalPlayerOne->iAmountOfTurns < LocalPlayerTwo->iAmountOfTurns ? processTurn(LocalPlayerOne) : processTurn(LocalPlayerTwo);




}

Game::Game()
{


}


Game::~Game()
{

}

