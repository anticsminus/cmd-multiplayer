#pragma once

#include <stack>

using namespace std;


class Piece
{
private: 


public:

	Piece();
	~Piece();
	int x;
		int y;

};

