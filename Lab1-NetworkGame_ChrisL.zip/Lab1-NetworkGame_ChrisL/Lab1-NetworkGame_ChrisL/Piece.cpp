#include "Piece.h"



Piece::Piece()
{
	
}


Piece::~Piece()
{
}
